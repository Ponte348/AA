Gonçalo Freitas, Mestrado em Engenharia Computacional, Nº Mec = 98012

Conteúdos do ficheiro .zip - Trabalho 2

	- Ficheiros .py com o código para a resolução deste problema (Exaustivo, Heuristico, Randomized, e Randomized_pre_defined_graphs para grafos da web)

	- Pasta Output com os ficheiros .txt com o Output de cada código

	- Ficheiro .pdf com o relatório

	- Ficheiro .zip com todos os requisitos para compilar o relatório em LaTex

	- Pasta 'Figuras' com os códigos desenvolvidos em Matlab para a obtenção das figuras apresentadas no relatório, e com as respetivas 
	figuras em formato .eps usadas no relatório

	- Pasta 'Grafos' com os ficheiros .txt (e ficheiro SW_ALGUNS_GRAFOS.zip que os contém) com os grafos da web estudados neste projeto

	- Nota: o ficheiro principal com os resultados respetivos ao algoritmo Randomized (i.e. aquele usado ao longo no projeto para 
	comparar com os algoritmos do projeto 1) é o 1000_combs_Randomized.txt