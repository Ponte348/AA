Gonçalo Freitas, Mestrado em Engenharia Computacional, Nº Mec = 98012

Conteúdos do ficheiro .zip

	- Ficheiro .py com o código para a resolução deste problema
	- Ficheiro .txt com o Output do código
	- Fichiero .pdf com o relatório
	- Pasta 'Figuras' com os códigos desenvolvidos em Matlab para a obtenção das figuras apresentadas no relatório